document.addEventListener('DOMContentLoaded', () => {
  console.log("Music Billboard loaded!");
});
