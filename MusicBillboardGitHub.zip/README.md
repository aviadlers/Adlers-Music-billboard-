# 🎶 Music Billboard

A simple music billboard-style website showcasing trending songs with audio previews.

## 🚀 Features
- Modern glowing design
- Dummy songs and images included
- Ready for GitHub Pages deployment

## 📂 Structure
- `index.html` → Main page
- `style.css` → Styling
- `app.js` → JavaScript interactions
- `assets/` → Contains sample images & mp3s

## 🌐 Deployment
This project is ready to be deployed on **GitHub Pages**:
1. Upload files to a new GitHub repository.
2. Go to **Settings > Pages**.
3. Set branch to `main` and folder to `/root`.
4. Visit your live site at `https://<username>.github.io/<repo-name>/`.

---

Built with ❤️ for experimenting and learning.
